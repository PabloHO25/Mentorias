library(shiny)
library(shinydashboard)
library(shinyjs)

header <- dashboardHeader()
sidebar <- dashboardSidebar(
  sidebarMenu(
  id="tabs",
    menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
  menuItem("Widgets", icon = icon("th"), tabName = "widgets",
           badgeLabel = "new", badgeColor = "green")
  )
)

body <- dashboardBody(
  useShinyjs(),
  includeCSS('style.css'),
  
  tabItems(
    
    tabItem(
      tabName = "panel1",
      fluidRow(
        column(6,
               box(width="100%",
                   title = "Editar Datos", status = "danger", solidHeader = TRUE,
                   collapsible = TRUE,
                   
               )
        ),
        column(6,
               box(width="100%",
                   title = "Registrar Evidencias", status = "success", solidHeader = TRUE,
                   collapsible = TRUE,
                   class = "img_asis", 
                   img(id="img_asis",src='asistencia.jpg', width="50%",height=100,align="center")
               )
        )
      ),
      fluidRow(
        
        column(6,
               box(width="100%",
                   title = "Consultar Horario", status = "info", solidHeader = TRUE,
                   collapsible = TRUE,
               )
        )
        ,
        column(6,
               box(width="100%",title= "Generar Reportes",status = "warning", solidHeader = TRUE,
                   collapsible = TRUE,))
        
      )
      
      
      
    ),
    tabItem(tabName = "panel2"),
    
  )
  
)

ui <- dashboardPage(header, sidebar, body)
 

server <- function(input, output) { }

shinyApp(ui, server)