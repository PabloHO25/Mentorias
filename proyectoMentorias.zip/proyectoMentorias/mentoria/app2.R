#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(sys)
library(shinyjs)


# Define UI for application that draws a histogram
ui <- dashboardPage(
  header <- dashboardHeader(),
  sidebar <-  dashboardSidebar(
    
    sidebarMenu(
      
      id = "tabs",
      menuItem("Pestaña",tabName = "panel1",icon("dashboard")),
      menuItem("Pestaña12", tabName = "panel2")
      
    )
    # 
    # id="tabs",
    # menuItem("tab1", tabName = "panel1"),
    # menuItem("tab2", tabName = "panel2"),
    
  ),
  body <- dashboardBody(
    useShinyjs(),
    includeCSS('style.css'),
    
    tabItems(
      
      tabItem(
        tabName = "panel1",
        fluidRow(
          column(6,
                 box(width="100%",
                     title = "Editar Datos", status = "danger", solidHeader = TRUE,
                     collapsible = TRUE,
                     
                 )
          ),
          column(6,
                 box(width="100%",
                     title = "Registrar Evidencias", status = "success", solidHeader = TRUE,
                     collapsible = TRUE,
                     class = "img_asis", 
                     img(id="img_asis",src='asistencia.jpg', width="50%",height=100,align="center")
                 )
          )
        ),
        fluidRow(
          
          column(6,
                 box(width="100%",
                     title = "Consultar Horario", status = "info", solidHeader = TRUE,
                     collapsible = TRUE,
                 )
          )
          ,
          column(6,
                 box(width="100%",title= "Generar Reportes",status = "warning", solidHeader = TRUE,
                     collapsible = TRUE,))
          
        )
        
        
        
      ),
      tabItem(tabName = "panel2")
      
    )
    
  )
  #cuadros para las acciones 
  
  
)
# Define server logic required to draw a histogram
server <- function(input, output) {
  
  
}

# Run the application 
ui = dashboardPage(header, sidebar, body)

shinyApp(ui, server)
